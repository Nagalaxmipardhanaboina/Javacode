package com.example.Software.SoftwareInterface;

import com.example.Software.Model.Software;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SoftwareInt extends JpaRepository<Software,Integer> {

	
	

}