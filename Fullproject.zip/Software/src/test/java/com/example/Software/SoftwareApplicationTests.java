package com.example.Software;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareApplicationTests {

	@Test
	void contextLoads() {
	}

}
