package com.example.Software.Controller;

import com.example.Software.InterfaceforDef.SoftwareIntforDef;
import com.example.Software.Model.Administrator;
import com.example.Software.Model.Software;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class SoftwareController{
	public SoftwareIntforDef service;

	public SoftwareController(SoftwareIntforDef service) {
		this.service = service;
	}
	@GetMapping("/viewAllSoftwares")
	public String listOfsoftwares(Model model) {
		model.addAttribute("softwareList",service.fetchAllRecords());
		return "software";  
	}

	@GetMapping("software/createNewSoftware")
	public String createSoftware(Model model) {
		Software emptyObj=new Software();
		model.addAttribute("softobj", emptyObj);
		return "createSoftware";
	}
	@PostMapping("/insertSoftwares")	
	public String InsertIntoDataBase(@ModelAttribute("softobj") Software obj) {
		service.saveSoftware(obj);
		return "redirect:/viewAllSoftwares";
	}

	@GetMapping("/delete/{id}")
	public String deleteSoftware(@PathVariable int id) {
		service.deleteSoftwarebyId(id);
		return "redirect:/viewAllSoftwares";
	}
	@GetMapping("/update/{id}")
	public String updateSoftwareRecr(@PathVariable int id, Model model) {
		model.addAttribute("updateSoftware", service.getSoftwareById(id));
		return "update_software";
	}
	@PostMapping("/updateAndSave/{id}")
	public String updateNewValIntoDb(@PathVariable int id,
			@ModelAttribute("updateSoftware") Software newVal) {
		Software existingSoft = service.getSoftwareById(id);
		existingSoft.setSoftwarename(newVal.getSoftwarename());
		existingSoft.setDescription(newVal.getDescription());
		existingSoft.setRating(newVal.getRating());
		existingSoft.setCost(newVal.getCost());

		service.saveSoftware(existingSoft);
		return "redirect:/viewAllSoftwares";
	}
@GetMapping("/logout")
public String logout() {
	return "logout";
}
	
	@GetMapping("/profile")
	public String profilepage() {
		return "profile";

}
	@GetMapping("/contact")
	public String contactpage() {
		return "contact";

}
	@GetMapping("/login")
	public String loginpage(Model model){
		Administrator admin=new Administrator();
		model.addAttribute("adminObj",admin);
		return "login";
}
	@GetMapping("/validatingData")
	public String validateLogin(@ModelAttribute("adminObj")Administrator adminData) {
		if(adminData.getUserName().equals("Nagalaxmi")&& adminData.getPassword().equals("Nagalaxmi@231")){
			return "redirect:/viewAllSoftwares";
		}
		else {
			return "redirect:/login";
		}
	}
}





